
"use strict";

let MeteoData = require('./MeteoData.js');

module.exports = {
  MeteoData: MeteoData,
};
