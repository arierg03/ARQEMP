
"use strict";

let InsertTask = require('./InsertTask.js')
let get_mode = require('./get_mode.js')
let set_mode = require('./set_mode.js')
let set_CartesianEuler_pose = require('./set_CartesianEuler_pose.js')
let GetPOI = require('./GetPOI.js')
let SetLaserMode = require('./SetLaserMode.js')
let SetBuzzer = require('./SetBuzzer.js')
let ack_alarm = require('./ack_alarm.js')
let SetString = require('./SetString.js')
let Record = require('./Record.js')
let SetTransform = require('./SetTransform.js')
let set_ptz = require('./set_ptz.js')
let SetCurrent = require('./SetCurrent.js')
let ResetFromSubState = require('./ResetFromSubState.js')
let axis_record = require('./axis_record.js')
let SetEncoderTurns = require('./SetEncoderTurns.js')
let set_named_digital_output = require('./set_named_digital_output.js')
let GetMotorsHeadingOffset = require('./GetMotorsHeadingOffset.js')
let set_analog_output = require('./set_analog_output.js')
let QueryAlarms = require('./QueryAlarms.js')
let SetInt16 = require('./SetInt16.js')
let enable_disable = require('./enable_disable.js')
let SetMotorMode = require('./SetMotorMode.js')
let LoggerQuery = require('./LoggerQuery.js')
let set_float_value = require('./set_float_value.js')
let SetByte = require('./SetByte.js')
let SetMotorStatus = require('./SetMotorStatus.js')
let set_odometry = require('./set_odometry.js')
let SetElevator = require('./SetElevator.js')
let SetNamedDigitalOutput = require('./SetNamedDigitalOutput.js')
let set_height = require('./set_height.js')
let get_modbus_register = require('./get_modbus_register.js')
let home = require('./home.js')
let SetMotorPID = require('./SetMotorPID.js')
let GetBool = require('./GetBool.js')
let get_alarms = require('./get_alarms.js')
let set_digital_output = require('./set_digital_output.js')
let set_modbus_register = require('./set_modbus_register.js')
let set_modbus_register_bit = require('./set_modbus_register_bit.js')
let GetPTZ = require('./GetPTZ.js')
let get_digital_input = require('./get_digital_input.js')

module.exports = {
  InsertTask: InsertTask,
  get_mode: get_mode,
  set_mode: set_mode,
  set_CartesianEuler_pose: set_CartesianEuler_pose,
  GetPOI: GetPOI,
  SetLaserMode: SetLaserMode,
  SetBuzzer: SetBuzzer,
  ack_alarm: ack_alarm,
  SetString: SetString,
  Record: Record,
  SetTransform: SetTransform,
  set_ptz: set_ptz,
  SetCurrent: SetCurrent,
  ResetFromSubState: ResetFromSubState,
  axis_record: axis_record,
  SetEncoderTurns: SetEncoderTurns,
  set_named_digital_output: set_named_digital_output,
  GetMotorsHeadingOffset: GetMotorsHeadingOffset,
  set_analog_output: set_analog_output,
  QueryAlarms: QueryAlarms,
  SetInt16: SetInt16,
  enable_disable: enable_disable,
  SetMotorMode: SetMotorMode,
  LoggerQuery: LoggerQuery,
  set_float_value: set_float_value,
  SetByte: SetByte,
  SetMotorStatus: SetMotorStatus,
  set_odometry: set_odometry,
  SetElevator: SetElevator,
  SetNamedDigitalOutput: SetNamedDigitalOutput,
  set_height: set_height,
  get_modbus_register: get_modbus_register,
  home: home,
  SetMotorPID: SetMotorPID,
  GetBool: GetBool,
  get_alarms: get_alarms,
  set_digital_output: set_digital_output,
  set_modbus_register: set_modbus_register,
  set_modbus_register_bit: set_modbus_register_bit,
  GetPTZ: GetPTZ,
  get_digital_input: get_digital_input,
};
