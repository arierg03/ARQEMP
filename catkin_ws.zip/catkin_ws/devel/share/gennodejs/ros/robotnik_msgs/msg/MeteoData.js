// Auto-generated. Do not edit!

// (in-package robotnik_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class MeteoData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.temperature = null;
      this.humidity = null;
      this.gasses = null;
      this.light = null;
      this.rain = null;
      this.pressure = null;
      this.internalTemperature = null;
      this.airParticlesDataAtmosferic1 = null;
      this.airParticlesDataAtmosferic2_5 = null;
      this.airParticlesDataAtmosferic10 = null;
    }
    else {
      if (initObj.hasOwnProperty('temperature')) {
        this.temperature = initObj.temperature
      }
      else {
        this.temperature = 0.0;
      }
      if (initObj.hasOwnProperty('humidity')) {
        this.humidity = initObj.humidity
      }
      else {
        this.humidity = 0.0;
      }
      if (initObj.hasOwnProperty('gasses')) {
        this.gasses = initObj.gasses
      }
      else {
        this.gasses = 0;
      }
      if (initObj.hasOwnProperty('light')) {
        this.light = initObj.light
      }
      else {
        this.light = 0;
      }
      if (initObj.hasOwnProperty('rain')) {
        this.rain = initObj.rain
      }
      else {
        this.rain = 0;
      }
      if (initObj.hasOwnProperty('pressure')) {
        this.pressure = initObj.pressure
      }
      else {
        this.pressure = 0.0;
      }
      if (initObj.hasOwnProperty('internalTemperature')) {
        this.internalTemperature = initObj.internalTemperature
      }
      else {
        this.internalTemperature = 0.0;
      }
      if (initObj.hasOwnProperty('airParticlesDataAtmosferic1')) {
        this.airParticlesDataAtmosferic1 = initObj.airParticlesDataAtmosferic1
      }
      else {
        this.airParticlesDataAtmosferic1 = 0;
      }
      if (initObj.hasOwnProperty('airParticlesDataAtmosferic2_5')) {
        this.airParticlesDataAtmosferic2_5 = initObj.airParticlesDataAtmosferic2_5
      }
      else {
        this.airParticlesDataAtmosferic2_5 = 0;
      }
      if (initObj.hasOwnProperty('airParticlesDataAtmosferic10')) {
        this.airParticlesDataAtmosferic10 = initObj.airParticlesDataAtmosferic10
      }
      else {
        this.airParticlesDataAtmosferic10 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MeteoData
    // Serialize message field [temperature]
    bufferOffset = _serializer.float32(obj.temperature, buffer, bufferOffset);
    // Serialize message field [humidity]
    bufferOffset = _serializer.float32(obj.humidity, buffer, bufferOffset);
    // Serialize message field [gasses]
    bufferOffset = _serializer.int32(obj.gasses, buffer, bufferOffset);
    // Serialize message field [light]
    bufferOffset = _serializer.int32(obj.light, buffer, bufferOffset);
    // Serialize message field [rain]
    bufferOffset = _serializer.int32(obj.rain, buffer, bufferOffset);
    // Serialize message field [pressure]
    bufferOffset = _serializer.float32(obj.pressure, buffer, bufferOffset);
    // Serialize message field [internalTemperature]
    bufferOffset = _serializer.float32(obj.internalTemperature, buffer, bufferOffset);
    // Serialize message field [airParticlesDataAtmosferic1]
    bufferOffset = _serializer.int32(obj.airParticlesDataAtmosferic1, buffer, bufferOffset);
    // Serialize message field [airParticlesDataAtmosferic2_5]
    bufferOffset = _serializer.int32(obj.airParticlesDataAtmosferic2_5, buffer, bufferOffset);
    // Serialize message field [airParticlesDataAtmosferic10]
    bufferOffset = _serializer.int32(obj.airParticlesDataAtmosferic10, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MeteoData
    let len;
    let data = new MeteoData(null);
    // Deserialize message field [temperature]
    data.temperature = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [humidity]
    data.humidity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gasses]
    data.gasses = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [light]
    data.light = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [rain]
    data.rain = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [pressure]
    data.pressure = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [internalTemperature]
    data.internalTemperature = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [airParticlesDataAtmosferic1]
    data.airParticlesDataAtmosferic1 = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [airParticlesDataAtmosferic2_5]
    data.airParticlesDataAtmosferic2_5 = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [airParticlesDataAtmosferic10]
    data.airParticlesDataAtmosferic10 = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 40;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotnik_msgs/MeteoData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'deb462be7ebb7699e92c1e6baee9b76c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 temperature
    float32 humidity
    int32 gasses
    int32 light
    int32 rain
    float32 pressure
    float32 internalTemperature
    int32 airParticlesDataAtmosferic1
    int32 airParticlesDataAtmosferic2_5
    int32 airParticlesDataAtmosferic10
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MeteoData(null);
    if (msg.temperature !== undefined) {
      resolved.temperature = msg.temperature;
    }
    else {
      resolved.temperature = 0.0
    }

    if (msg.humidity !== undefined) {
      resolved.humidity = msg.humidity;
    }
    else {
      resolved.humidity = 0.0
    }

    if (msg.gasses !== undefined) {
      resolved.gasses = msg.gasses;
    }
    else {
      resolved.gasses = 0
    }

    if (msg.light !== undefined) {
      resolved.light = msg.light;
    }
    else {
      resolved.light = 0
    }

    if (msg.rain !== undefined) {
      resolved.rain = msg.rain;
    }
    else {
      resolved.rain = 0
    }

    if (msg.pressure !== undefined) {
      resolved.pressure = msg.pressure;
    }
    else {
      resolved.pressure = 0.0
    }

    if (msg.internalTemperature !== undefined) {
      resolved.internalTemperature = msg.internalTemperature;
    }
    else {
      resolved.internalTemperature = 0.0
    }

    if (msg.airParticlesDataAtmosferic1 !== undefined) {
      resolved.airParticlesDataAtmosferic1 = msg.airParticlesDataAtmosferic1;
    }
    else {
      resolved.airParticlesDataAtmosferic1 = 0
    }

    if (msg.airParticlesDataAtmosferic2_5 !== undefined) {
      resolved.airParticlesDataAtmosferic2_5 = msg.airParticlesDataAtmosferic2_5;
    }
    else {
      resolved.airParticlesDataAtmosferic2_5 = 0
    }

    if (msg.airParticlesDataAtmosferic10 !== undefined) {
      resolved.airParticlesDataAtmosferic10 = msg.airParticlesDataAtmosferic10;
    }
    else {
      resolved.airParticlesDataAtmosferic10 = 0
    }

    return resolved;
    }
};

module.exports = MeteoData;
