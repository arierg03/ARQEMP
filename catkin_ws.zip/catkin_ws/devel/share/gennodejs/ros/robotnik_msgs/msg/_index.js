
"use strict";

let Register = require('./Register.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let PantiltStatusStamped = require('./PantiltStatusStamped.js');
let Registers = require('./Registers.js');
let MotorCurrent = require('./MotorCurrent.js');
let MotorReferenceValue = require('./MotorReferenceValue.js');
let StringArray = require('./StringArray.js');
let WatchdogStatus = require('./WatchdogStatus.js');
let named_input_output = require('./named_input_output.js');
let LaserStatus = require('./LaserStatus.js');
let InverterStatus = require('./InverterStatus.js');
let AlarmSensor = require('./AlarmSensor.js');
let Logger = require('./Logger.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let ElevatorAction = require('./ElevatorAction.js');
let OdomManualCalibrationStatus = require('./OdomManualCalibrationStatus.js');
let StringStamped = require('./StringStamped.js');
let State = require('./State.js');
let Interfaces = require('./Interfaces.js');
let QueryAlarm = require('./QueryAlarm.js');
let MotorReferenceValueArray = require('./MotorReferenceValueArray.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let inputs_outputs = require('./inputs_outputs.js');
let ptz = require('./ptz.js');
let OdomCalibrationStatus = require('./OdomCalibrationStatus.js');
let BoolArray = require('./BoolArray.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let OdomManualCalibrationStatusStamped = require('./OdomManualCalibrationStatusStamped.js');
let MotorStatus = require('./MotorStatus.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let Pose2DArray = require('./Pose2DArray.js');
let Axis = require('./Axis.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let alarmmonitor = require('./alarmmonitor.js');
let SubState = require('./SubState.js');
let ReturnMessage = require('./ReturnMessage.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let MotorsStatus = require('./MotorsStatus.js');
let WatchdogStatusArray = require('./WatchdogStatusArray.js');
let MotorPID = require('./MotorPID.js');
let MeteoData = require('./MeteoData.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let OdomCalibrationStatusStamped = require('./OdomCalibrationStatusStamped.js');
let Alarms = require('./Alarms.js');
let PresenceSensor = require('./PresenceSensor.js');
let RecordStatus = require('./RecordStatus.js');
let Data = require('./Data.js');
let ArmStatus = require('./ArmStatus.js');
let PantiltStatus = require('./PantiltStatus.js');
let encoders = require('./encoders.js');
let BatteryStatus = require('./BatteryStatus.js');
let LaserMode = require('./LaserMode.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');

module.exports = {
  Register: Register,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  SafetyModuleStatus: SafetyModuleStatus,
  PantiltStatusStamped: PantiltStatusStamped,
  Registers: Registers,
  MotorCurrent: MotorCurrent,
  MotorReferenceValue: MotorReferenceValue,
  StringArray: StringArray,
  WatchdogStatus: WatchdogStatus,
  named_input_output: named_input_output,
  LaserStatus: LaserStatus,
  InverterStatus: InverterStatus,
  AlarmSensor: AlarmSensor,
  Logger: Logger,
  BatteryStatusStamped: BatteryStatusStamped,
  ElevatorAction: ElevatorAction,
  OdomManualCalibrationStatus: OdomManualCalibrationStatus,
  StringStamped: StringStamped,
  State: State,
  Interfaces: Interfaces,
  QueryAlarm: QueryAlarm,
  MotorReferenceValueArray: MotorReferenceValueArray,
  BatteryDockingStatus: BatteryDockingStatus,
  inputs_outputs: inputs_outputs,
  ptz: ptz,
  OdomCalibrationStatus: OdomCalibrationStatus,
  BoolArray: BoolArray,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  named_inputs_outputs: named_inputs_outputs,
  OdomManualCalibrationStatusStamped: OdomManualCalibrationStatusStamped,
  MotorStatus: MotorStatus,
  alarmsmonitor: alarmsmonitor,
  PresenceSensorArray: PresenceSensorArray,
  Pose2DArray: Pose2DArray,
  Axis: Axis,
  ElevatorStatus: ElevatorStatus,
  alarmmonitor: alarmmonitor,
  SubState: SubState,
  ReturnMessage: ReturnMessage,
  MotorsStatusDifferential: MotorsStatusDifferential,
  MotorsStatus: MotorsStatus,
  WatchdogStatusArray: WatchdogStatusArray,
  MotorPID: MotorPID,
  MeteoData: MeteoData,
  Pose2DStamped: Pose2DStamped,
  MotorHeadingOffset: MotorHeadingOffset,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  OdomCalibrationStatusStamped: OdomCalibrationStatusStamped,
  Alarms: Alarms,
  PresenceSensor: PresenceSensor,
  RecordStatus: RecordStatus,
  Data: Data,
  ArmStatus: ArmStatus,
  PantiltStatus: PantiltStatus,
  encoders: encoders,
  BatteryStatus: BatteryStatus,
  LaserMode: LaserMode,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorResult: SetElevatorResult,
  SetElevatorAction: SetElevatorAction,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorFeedback: SetElevatorFeedback,
};
