robotnik_msgs
=============

Definition of msgs and services used by some Robotnik's packages
