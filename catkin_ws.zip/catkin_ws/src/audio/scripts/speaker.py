import pyttsx3
import rospy
from std_msgs.msg import String
from datetime import datetime

#Declaracion de los logs
logs_path = '/home/ubuntu/catkin_ws/src/audio/scripts/say_logs.txt'
log_publisher = None

#Declaraciones del altavoz
engine = pyttsx3.init(driverName='espeak',debug=True)
engine.setProperty('voice', 'es')
engine.setProperty('volume', 1.0)

#Funcionamiento cuando se recibe datos
def callback(data):
    rospy.loginfo("Recibido: %s", data.data)
    result = data.data
    
    #Inicia la nueva reproduccion
    engine.say(result)
    engine.runAndWait()

    # Construir la línea de log con [fecha - hora] mensaje leído
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{now}] {result}"
    with open(logs_path, "a") as f:
        f.write(log_line + "\n")

    # Publicar el contenido del archivo en el tópico
    global log_publisher
    log_publisher.publish("INICIO DE LOGS")
    with open(logs_path, "r") as f:
        content = f.readlines()
        for line in content:
            log_publisher.publish(line.strip())
    log_publisher.publish("FIN DE LOGS")
    
#Funcion principal que inicializa el nodo y se suscribe y crea el publicador necesarios
def listener():
    rospy.init_node('audio', anonymous=True)
    #Inicializamos el publicador para el tópico de logs
    global log_publisher
    log_publisher = rospy.Publisher('/audio_say_logs', String, queue_size=10)
    rospy.Subscriber('/audio_say', String, callback)
    rospy.loginfo("Nodo inicializado")
    rospy.spin()

if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
