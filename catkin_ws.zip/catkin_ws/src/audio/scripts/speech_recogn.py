from cgitb import text
import speech_recognition as sr
import pyttsx3
import rospy
from robotnik_msgs.msg import BatteryStatus
from meteo_station_server.msg import MeteoData
from std_msgs.msg import String
from datetime import datetime
import locale
import pytz
import time
from unidecode import unidecode

#Variables globales necesarias
logs_path = '/home/ubuntu/catkin_ws/src/audio/scripts/speech_recogn.txt'
log_publisher = None
finish = False
nivel_bateria = None
battery_time_remaining = None
battery_time_charging = None
temperature = None
humidity = None
pressure = None


#Declaramos el recognizer y el altavoz
recognizer = sr.Recognizer()
engine = pyttsx3.init(driverName='espeak',debug=True)
engine.setProperty('voice', 'es')
engine.setProperty('volume', 1.0)

#Funciones de lectura de tópicos
#Funcion que lee la temperatura ambiente
def leeTemperatura():
    def callback(data):
        global temperature
        temperature = f"La temperatura es de: {str(data.temperature)} grados"
        rospy.loginfo(temperature)
        rospy.signal_shutdown('Temperatura recibida')
    rospy.Subscriber("/meteo_data", MeteoData, callback)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    return temperature
#Funcion que lee la humedad
def leeHumedad():
    def callback(data):
        global humidity
        humidity = f"La humedad es del: {str(data.humidity)} por ciento"
        rospy.loginfo(humidity)
        rospy.signal_shutdown('Humedad recibida')
    rospy.Subscriber("/meteo_data", MeteoData, callback)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    return humidity
#Funcion que lee la presion atmosferica
def leePresion():
    def callback(data):
        global pressure
        pressure = f"La presion es de: {str(data.pressure)}"
        rospy.loginfo(pressure)
        rospy.signal_shutdown('Presion recibida')
    rospy.Subscriber("/meteo_data", MeteoData, callback)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    return pressure
#Función que lee el nivel de la bateria
def leeNivelBateria():
    def callback(data):
        global nivel_bateria
        nivel_bateria = f"El nivel de la bateria es: {str(int(data.level))}"
        rospy.loginfo(nivel_bateria)
        rospy.signal_shutdown('Nivel de bateria recibido')
    rospy.Subscriber("/robot/battery_estimator/data", BatteryStatus, callback)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    return nivel_bateria
#Función que lee cuanto queda de batería
def leeTiempoRestanteBateria():
    def callback(data):
        global battery_time_remaining
        battery_time_remaining = f"El tiempo restante de la bateria es: {str(int(data.time_remaining))}"
        rospy.loginfo(battery_time_remaining)
        rospy.signal_shutdown('Tiempo de bateria restante recibido')
    rospy.Subscriber("/robot/battery_estimator/data", BatteryStatus, callback)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    return battery_time_remaining
#Función que lee cuanto tiempo lleva de cargando
def leeTiempoCargaBateria():
    def callback(data):
        global battery_time_charging
        battery_time_charging = f"El tiempo que lleva cargando es: {str(int(data.time_charging))} minutos"
        rospy.loginfo(battery_time_charging)
        rospy.signal_shutdown('Tiempo de carga de bateria recibido')
    rospy.Subscriber("/robot/battery_estimator/data", BatteryStatus, callback)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    return battery_time_charging
#Funcion que devuelve la hora en modo de mensaje
def leeHora():
    actual_utc = datetime.utcnow()
    spanish_tz = pytz.timezone('Europe/Madrid')
    spanish_now = actual_utc.replace(tzinfo=pytz.utc).astimezone(spanish_tz)
    now = spanish_now.strftime("%H horas y %M minutos")
    right_now = f"Son las {now}"
    return right_now
#Funcion que devuelve la fecha en modo de mensaje
def leeFecha():
    now = datetime.now().strftime("dia %d de %m del %Y")
    today = f"Hoy es {now}"
    return today
#Funcion que produce que se termine el programa
def terminarPrograma():
    global finish
    finish = True
    return "Hasta luego"
#Funcion que chequea la variable finish para ver si debe parar
def checkFinish():
    global finish
    value = finish
    return value
#Funcion que publica los logs cuando es necesario
def publica_logs():
    global log_publisher
    log_publisher.publish("INICIO DE LOGS")
    with open(logs_path, 'r') as file:
        content = file.readlines()
        for line in content:
            line_sin_tildes = unidecode(line).strip('\n')
            log_publisher.publish(line_sin_tildes)
    log_publisher.publish("FIN DE LOGS")


#Diccionario de palabras clave para detectar en el audio escuchado
keywords = {
    'hola': 'buenas',
    'cómo estás': 'muy bien, tranquilito',
    'chiste': 'Eliminar correos no deseados es muy facil: SPAM comido',

    'apágate': terminarPrograma,
    'deja de escuchar': terminarPrograma,

    'dime la hora': leeHora,
    'dame la hora': leeHora,
    'qué fecha es hoy': leeFecha,
    'qué día es hoy': leeFecha,

    'porcentaje de batería': leeNivelBateria,
    'nivel de batería': leeNivelBateria,
    'nivel de la batería': leeNivelBateria,

    'queda de batería': leeTiempoRestanteBateria,
    'tiempo restante de batería': leeTiempoRestanteBateria,
    'tiempo restante de la batería': leeTiempoRestanteBateria,

    'tiempo de carga': leeTiempoCargaBateria,
    'cuanto tiempo lleva cargando': leeTiempoCargaBateria,
    'tiempo que lleva cargando': leeTiempoCargaBateria,

    'dame la temperatura': leeTemperatura,
    'dime la temperatura': leeTemperatura,
    'qué temperatura hace': leeTemperatura,

    'qué humedad hay': leeHumedad,
    'qué humedad hace': leeHumedad,
    'dime la humedad': leeHumedad,

    'qué presión hay': leePresion,
    'qué presión atmosfética hay': leePresion,
    'dame la presión': leePresion,
}

if __name__ == '__main__':
    rospy.init_node('speech_recogn', anonymous=True)
    log_publisher = rospy.Publisher('speech_recogn_log', String, queue_size=10)
    is_finish = checkFinish()
    while not rospy.is_shutdown() and not is_finish:  # Bucle principal hasta que se reciba una señal de parada
        with sr.Microphone() as source:
            print("Habla algo...")
            audio = recognizer.listen(source)

        try:
            text = recognizer.recognize_google(audio, language="es-ES")
            for key, response in keywords.items():
                if key in text:
                    if callable(response):
                        result = response()
                        print(result)
                        engine.say(result)
                        engine.runAndWait()
                    else:
                        print(response)
                        engine.say(response)
                        engine.runAndWait()

            # Guarda las palabras transcritas en un archivo de texto
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_line = f"[{now}] {text}"
            with open(logs_path, "a") as file:
                file.write(log_line + "\n")
            # Publicar el contenido del archivo en el tópico
            publica_logs()

        except sr.UnknownValueError:
            print("No se pudo entender el audio")
        except sr.RequestError as e:
            print("Error en la solicitud: {0}".format(e))
        is_finish = checkFinish()
